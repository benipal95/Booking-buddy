package group10.tcss450.uw.edu.bookingbuddy;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link FlightListFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class FlightListFragment extends Fragment {

    private OnFragmentInteractionListener mListener;

    public FlightListFragment() {
        // Required empty public constructor
    }

    @Override
    public void onStart()
    {
        super.onStart();
        if (getArguments() != null)
        {
            String origin = getArguments().getString("ORIGIN");
            String dest = getArguments().getString("DESTI");
            AsyncTask<String, Void, String> task = null;

            task = new FlightSearchTask();
            task.execute(origin, dest);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_flight_list, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri); // Don't know yet if we'll need this, but including it just in case
    }

    private class FlightSearchTask extends AsyncTask<String, Void, String>
    {

        private static final String URL_START = "http://api.travelpayouts.com/v1/prices/monthly?currency=USD&origin=";
        private static final String URL_MIDDLE = "&destination=";
        private static final String URL_END = "&token=9f0202d35e6767803ce5e453f702e6f6";

        private static final String TEST_A = "SEA"; // Remove these later
        private static final String TEST_B = "LAX";

        @Override
        protected String doInBackground(String... strings) {
            String response = "";
            HttpURLConnection connection = null;
            String origin = strings[0];
            String destination = strings[1];

            try
            {
                URL urlObj = new URL(URL_START + TEST_A + URL_MIDDLE + TEST_B + URL_END);
                connection = (HttpURLConnection) urlObj.openConnection();
                InputStream content = connection.getInputStream();
                BufferedReader buffer = new BufferedReader(new InputStreamReader(content));
                String s = "";
                while ((s = buffer.readLine()) != null)
                {
                    response += s;
                }
            }
            catch (Exception e)
            {
                response = "Unable to connect, Reason: " + e.getMessage();
            }
            finally
            {
                if (connection != null)
                    connection.disconnect();
            }


            return response;
        }

        @Override
        protected void onPostExecute(String result)
        {
            TextView tx_results = getActivity().findViewById(R.id.tx_flight_list);
            tx_results.setText(result);
        }
    }
}
